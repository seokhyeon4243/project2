/**
 * 
 */
 function sendidfind(){
	var name = document.getElementsByName("name")[0].value;
	var jumin1 = document.getElementsByName("jumin1")[0].value;
	var jumin2 = document.getElementsByName("jumin2")[0].value;

	if(name ==''){
		alert('NAME를 입력해주세요.');
		return false;
	}
	else if(jumin1 ==''){
		alert('주민번호를 입력해주세요.');
		return false;
	}
	else if(jumin2 ==''){
		alert('주민번호를 입력해주세요.');
		return false;
	}
}