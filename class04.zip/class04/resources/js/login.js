/**
 * 
 */
 function sendlogin(){
	var id = document.getElementsByName("id")[0].value;
	var pw = document.getElementsByName("pw")[0].value;

	if(id ==''){
		alert('ID를 입력해주세요.');
		return false;
	}
	else if(pw ==''){
		alert('패스워드를 입력해주세요.');
		return false;
	}
}