/**
 * 
 */
function sendinfo(){
	var id = document.getElementsByName("id")[0].value;
	var pw = document.getElementsByName("pw")[0].value;
	var name = document.getElementsByName("name")[0].value;
	var jumin1 = document.getElementsByName("jumin1")[0].value;
	var jumin2 = document.getElementsByName("jumin2")[0].value;
	if(id ==''){
		alert('ID를 입력해주세요.');
		return false;
	}
	else if(pw ==''){
		alert('패스워드를 입력해주세요.');
		return false;
	}
	else if(name ==''){
		alert('이름을 입력해주세요.');
		return false;
	}
	else if(jumin1 ==''){
		alert('주민번호를 입력해주세요.');
		return false;
	}
	else if(jumin2 ==''){
		alert('주민번호를 입력해주세요.');
		return false;
	}
}